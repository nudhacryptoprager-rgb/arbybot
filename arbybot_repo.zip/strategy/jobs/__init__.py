"""
strategy/jobs - CLI entrypoints for scanning and paper trading.
"""
